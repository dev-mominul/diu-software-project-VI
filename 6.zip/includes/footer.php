<!-- footer.php -->
<footer class="bg-gray-50 text-gray-400 py-4 mt-0">
    <div class="text-center">
        <p class="text-sm">
            &copy; <?= date("Y"); ?> Mominul Islam | DIU ID 192-15-13156. <br>
            This project is presented as part of CSE336: Software Project VI, Dept. of CSE, DIU.
        </p>
    </div>
</footer>
